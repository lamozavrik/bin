<?php

namespace app\lime\modules\sites;

use app\lime\core\BaseModule;

class Module extends BaseModule
{

    public function init()
    {

        parent::init();

    }
}
