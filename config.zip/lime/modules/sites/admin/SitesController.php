<?php

namespace app\lime\modules\sites\admin;

use yii\web\Controller;

class SitesController extends Controller{

	public function actionIndex(){
		return __METHOD__;
	}

	public function actionFoo(){
		return __METHOD__;
	}

}