<?php

namespace app\lime\modules\admin;

use app\lime\core\BaseModule;

class Module extends BaseModule
{

    public function init()
    {

        parent::init();

    }
}
