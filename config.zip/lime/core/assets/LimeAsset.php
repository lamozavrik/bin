<?php
namespace app\lime\core\assets;

use yii\web\AssetBundle;

class LimeAsset extends AssetBundle{
    public $basePath = '@app/lime/assets';
    public $baseUrl = '@web/lime/assets';

}